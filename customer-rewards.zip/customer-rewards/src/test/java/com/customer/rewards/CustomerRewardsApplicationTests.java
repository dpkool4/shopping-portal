package com.customer.rewards;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.customer.rewards.bean.RewardTransactionBean;
import com.customer.rewards.entity.Customer;
import com.customer.rewards.service.CustomerRewardService;
import com.customer.rewards.service.TransactionService;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class CustomerRewardsApplicationTests {

    @Test
	void contextLoads() {
	}
	
   
	@Autowired
    CustomerRewardService customerRewardsService;
	@Autowired
    TransactionService transactionService;
	

	
	@Test
	void testCustomerRewardsforSingleUser() {
		Customer customer=customerRewardsService.customerRewardsById(1);
		if(customer.getId()==1) {
			Assertions.assertEquals(90,customer.getTotalRewardAmount());
		}		
	}
	
	@Test
	void testCustomerRewardsforCustomerNotFoundException() {
		Customer customer=customerRewardsService.customerRewardsById(6);
		Assertions.assertNull(customer);;		
	}
	
	@Test
	void testCustomerRewardsforAll() {
		List<Customer> customer=customerRewardsService.customerRewardsForAll();
		if(customer.get(0).getId()==1) {
			Assertions.assertEquals(90,customer.get(0).getTotalRewardAmount());
		}		
	}
	
	
		@Test
	void testCustomerRewardforAmountBelowFifty() {
		Customer customer=customerRewardsService.customerRewardsById(2);
		if(customer.getId()==2) {
			Assertions.assertEquals(0,customer.getTotalRewardAmount());
		}		
	}
	
	
	@Test
	void testCustomerRewardforAmountAboveFiftyBelowHundred() {
		Customer customer=customerRewardsService.customerRewardsById(3);
		if(customer.getId()==3) {
			Assertions.assertEquals(20,customer.getTotalRewardAmount());
		}		
	}
	
	@Test
	void testCustomerRewardforAmountAboveHundred() {
		Customer customer=customerRewardsService.customerRewardsById(1);
		if(customer.getId()==1) {
			Assertions.assertEquals(90,customer.getTotalRewardAmount());
		}		
	}

	@Test
	void testCustomerRewardforDateNotExistIn3Months() {
		Customer customer=customerRewardsService.customerRewardsById(4);
		if(customer.getId()==4) {
			Assertions.assertEquals(0,customer.getTotalRewardAmount());
		}		
	}
	
	@Test
	void testCustomerRewardforInsertion() {
		int customerid=transactionService.insertTransactionData(setRewardBean());
			Assertions.assertEquals(4,customerid);
		
	}
	
	
	public RewardTransactionBean setRewardBean() {
		
		RewardTransactionBean bean = new RewardTransactionBean();
		bean.setCustomerName("PK");
		bean.setTransactionAmount(500);
		bean.setTransactionDate("2023-08-01");
		return bean;
		
	}
	
}

ALTER TABLE reward_transaction ADD FOREIGN KEY (CUSTOMER_ID) REFERENCES CUSTOMER (ID);


Insert into CUSTOMER values(1,'Savita');
Insert into CUSTOMER values(2,'Infogain');
Insert into CUSTOMER values(3,'Avaya');
Insert into CUSTOMER values(4,'Avaya1');




Insert into REWARD_TRANSACTION(id,customer_id, transaction_amount, transaction_date)  values(1,1,120,'2023-08-01');
Insert into REWARD_TRANSACTION(id,customer_id, transaction_amount, transaction_date) values(2,2,24,'2023-07-07');
Insert into REWARD_TRANSACTION(id,customer_id, transaction_amount, transaction_date) values(3,3,70,'2023-06-06');
Insert into REWARD_TRANSACTION(id,customer_id, transaction_amount, transaction_date) values(4,4,50,'2023-01-05');
Insert into REWARD_TRANSACTION(id,customer_id, transaction_amount, transaction_date) values(5,4,50,'2023-01-05');


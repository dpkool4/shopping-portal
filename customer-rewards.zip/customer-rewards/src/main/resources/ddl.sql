DROP TABLE IF EXISTS customer;
  
CREATE SEQUENCE customer_sequence
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE customer (
  id int PRIMARY KEY default customer_sequence.nextval,
  name VARCHAR(100) NOT NULL);

  
  CREATE SEQUENCE transaction_sequence
  START WITH 1
  INCREMENT BY 1;
  


DROP TABLE IF EXISTS reward_transaction;
  
CREATE TABLE reward_transaction (
  id int PRIMARY KEY default transaction_sequence.nextval ,
  customer_id number ,
  transaction_amount number ,
  transaction_date DATE  
);





package com.customer.rewards.repository;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.customer.rewards.entity.Customer;

@Repository
public interface CustomerRewardRepository extends JpaRepository<Customer, Integer>{

	Optional<Customer> findByNameIgnoreCase(String name);
	
	 @Query(value = "SELECT customer_seq.nextval FROM dual", nativeQuery = true)
	    public int getNextValCustomerSequence();
}

package com.customer.rewards.bean;

import javax.validation.constraints.NotBlank;

public class CustomerBean{
	

    @NotBlank(message = "Name is mandatory")
	private String name;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

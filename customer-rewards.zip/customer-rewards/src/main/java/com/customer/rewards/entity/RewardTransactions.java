package com.customer.rewards.entity;



import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Reward_Transaction")
@Data
public class RewardTransactions {
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setCreationDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	 @Id
	 @GeneratedValue(generator = "transaction_sequence") 
	  @SequenceGenerator(name = "transaction_sequence", sequenceName = "transaction_seq", initialValue=5,allocationSize = 1)
	private int id;

	@ManyToOne
	@JoinColumn(name = "CUSTOMER_ID")
	private Customer customer;

	@Column(name = "transaction_amount")
	int transactionAmount;
	
	@Column(name = "transaction_date")
	LocalDate transactionDate;
}

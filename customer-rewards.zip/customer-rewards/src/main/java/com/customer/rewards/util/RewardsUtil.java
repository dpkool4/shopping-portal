package com.customer.rewards.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.customer.rewards.constant.ApplicationConstant;

@Component
public class RewardsUtil {
    Logger logger = LoggerFactory.getLogger(RewardsUtil.class);

    public int calculateRewardAmountPerTrans(int transactionAmount) {
        logger.debug("Transaction Amount : " + transactionAmount);

        int rewardAmount = 0;
        if (transactionAmount > 100) {
            rewardAmount = (ApplicationConstant.REWARD_POINT_OVER_100 * (transactionAmount - 100) + ApplicationConstant.REWARD_POINT_OVER_50 * 50);
        } else if(transactionAmount > 50){
            rewardAmount =  ApplicationConstant.REWARD_POINT_OVER_50 * (transactionAmount - 50);
        }

        logger.info("Reward Amount:::" + rewardAmount);
        return rewardAmount;
    }
    
    
    public boolean isDateFormatValid(LocalDate date) {
    	final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY"); 
    	String formattedDateTime = date.format(formatter);
    	if(formattedDateTime.equals(date.toString())) {
    		return true;
    	} 
    	return false;

    }
}

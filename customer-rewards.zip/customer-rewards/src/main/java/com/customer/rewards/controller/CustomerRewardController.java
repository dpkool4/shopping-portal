package com.customer.rewards.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xmlunit.builder.Input;

import com.customer.rewards.bean.RewardTransactionBean;
import com.customer.rewards.entity.Customer;
import com.customer.rewards.exception.CustomerNotFoundException;
import com.customer.rewards.service.CustomerRewardService;
import com.customer.rewards.service.TransactionService;

@RestController
@RequestMapping("/customer/rewards")
public class CustomerRewardController {

	Logger logger = LoggerFactory.getLogger(CustomerRewardController.class);

	@Autowired
	private CustomerRewardService customerRewardService;

	@Autowired
	private TransactionService transactionService;

	@GetMapping
	public ResponseEntity<Object> getCustomerRewards() {
		logger.info("In CustomerRewardController -> getCustomerRewards method start");
		List<Customer> customerList = customerRewardService.customerRewardsForAll();

		if (customerList.isEmpty() || customerList.size() == 0) {
			logger.error("In getCustomerRewards method -> Customer List is empty");
			throw new CustomerNotFoundException("Customers not available");
		}

		return new ResponseEntity<>(customerList, HttpStatus.OK);
	}

	@GetMapping(value = "/{customerId}")
	public ResponseEntity<Customer> getCustomerRewardById(@PathVariable int customerId) {
		logger.info("In CustomerRewardController -> getCustomerRewardById method start");
		Customer customerReward = customerRewardService.customerRewardsById(customerId);

		if (customerReward == null) {
			logger.error("In getCustomerRewardById method -> No Customer Record Found");
			throw new CustomerNotFoundException("CustomerId" + customerId + " does not exist");
		}

		return new ResponseEntity<Customer>(customerReward, HttpStatus.OK);
	}

	@PostMapping(value = "/insertTransaction")
	public ResponseEntity<String> saveTransactionData(@Valid @RequestBody RewardTransactionBean bean) {

		/*Set<ConstraintViolation<Input>> violations = validator.validate(customer);
		if (!violations.isEmpty()) {
		  throw new ConstraintViolationException(violations);
		}*/
		
		int customerID = transactionService.insertTransactionData(bean);

		return new ResponseEntity<String>("Data Inserted Succesfully for customer id :" + customerID, HttpStatus.OK);
	}

}

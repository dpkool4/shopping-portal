package com.customer.rewards.util;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

public class ErrorDetails {
    Logger logger = LoggerFactory.getLogger(ErrorDetails.class);

    private LocalDate timestamp;
    private String message;
    private HttpStatus status;

    public ErrorDetails(LocalDate timestamp, String message, HttpStatus status) {
        this.timestamp = timestamp;
        this.message = message;
        this.status = status;
    }

    public LocalDate getTimestamp() {
        return timestamp;
    }

    public String getMessage() {
        return message;
    }

    public HttpStatus getStatus() {
        return status;
    }
}

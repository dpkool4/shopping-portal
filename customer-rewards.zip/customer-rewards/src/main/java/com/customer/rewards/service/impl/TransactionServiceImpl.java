package com.customer.rewards.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.rewards.bean.RewardTransactionBean;
import com.customer.rewards.entity.Customer;
import com.customer.rewards.entity.RewardTransactions;
import com.customer.rewards.repository.CustomerRewardRepository;
import com.customer.rewards.repository.TransactionRepository;
import com.customer.rewards.service.TransactionService;
import com.customer.rewards.util.RewardsUtil;

@Service
public class TransactionServiceImpl implements TransactionService {
	Logger logger = LoggerFactory.getLogger(TransactionServiceImpl.class);

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	CustomerRewardRepository customerRewardRepository;

	@Autowired
	RewardsUtil rewardsUtil;

	@Override
	public int insertTransactionData(RewardTransactionBean rewardTransactionBean) {

		RewardTransactions transaction = new RewardTransactions();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.parse(rewardTransactionBean.getTransactionDate(), dateTimeFormatter);
		int customerId = 0;
		Optional<Customer> customer = customerRewardRepository
				.findByNameIgnoreCase(rewardTransactionBean.getCustomerName());
		transaction.setCreationDate(localDate);
		transaction.setTransactionAmount(rewardTransactionBean.getTransactionAmount());
		if (customer.isPresent()) {
			customerId = customer.get().getId();
			transaction.setCustomer(customer.get());
			transaction.setId(transactionRepository.getNextValTransactionSequence());
		} else {
			Customer customerEntity = new Customer();
			customerEntity.setName(rewardTransactionBean.getCustomerName());
			customerEntity.setId(customerRewardRepository.getNextValCustomerSequence());
			customerRewardRepository.save(customerEntity);
			transaction.setId(transactionRepository.getNextValTransactionSequence());
			Customer customernew = customerRewardRepository.findByNameIgnoreCase(rewardTransactionBean.getCustomerName()).get();
			transaction.setCustomer(customernew);
			customerId = customernew.getId();

		}

		transactionRepository.save(transaction);

		return customerId;

	}

}

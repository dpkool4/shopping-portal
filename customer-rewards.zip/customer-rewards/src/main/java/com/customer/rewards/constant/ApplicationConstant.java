package com.customer.rewards.constant;

import java.util.HashMap;

public class ApplicationConstant {
	
	public static int  REWARD_POINT_OVER_50 = 1 ;
	public static int  REWARD_POINT_OVER_100 = 2 ;
	public static String CUSTOMER_NOT_FOUND = "Customer not found for given Customer ID";
	public static String REQUESTBODY_DATEFORMAT_INCORRECT = "DateFormat is not valid use \"yyyy-MM-dd";
	public static String INTERNAL_ERROR = "internal server error";
	public static String REQUESTBODY_NOT_VALID = "Request body not valid for ";

}

package com.customer.rewards.exception;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.customer.rewards.constant.ApplicationConstant;
import com.customer.rewards.util.ErrorDetails;

@ControllerAdvice
public class ApplicationExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(CustomerNotFoundException.class)
	public final ResponseEntity<ErrorDetails> handleUserNotFoundException(CustomerNotFoundException ex) {
		ErrorDetails error = new ErrorDetails(LocalDate.now(), ApplicationConstant.CUSTOMER_NOT_FOUND,
				HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}
	
	 @Override
	    protected ResponseEntity<Object> handleMethodArgumentNotValid
	            (MethodArgumentNotValidException ex,
	                 HttpHeaders headers, HttpStatus status, WebRequest request)     {
		 
		 ErrorDetails error = new ErrorDetails(LocalDate.now(), ApplicationConstant.REQUESTBODY_NOT_VALID + ex.getFieldError().getField(),
					HttpStatus.BAD_REQUEST);
			return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	    }

	@ExceptionHandler(DateTimeParseException.class)
	public final ResponseEntity<ErrorDetails> handleDateTimeParseException(DateTimeParseException ex) {
		ErrorDetails error = new ErrorDetails(LocalDate.now(), ApplicationConstant.REQUESTBODY_DATEFORMAT_INCORRECT,
				HttpStatus.BAD_REQUEST);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	public final ResponseEntity<ErrorDetails> handleConstraintViolationException(ConstraintViolationException ex) {
		ErrorDetails error = new ErrorDetails(LocalDate.now(), ApplicationConstant.REQUESTBODY_NOT_VALID,
				HttpStatus.BAD_REQUEST);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, RequestBody request) {

		ErrorDetails error = new ErrorDetails(LocalDate.now(), ApplicationConstant.INTERNAL_ERROR,
				HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}

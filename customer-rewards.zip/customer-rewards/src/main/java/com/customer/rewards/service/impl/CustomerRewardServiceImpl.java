package com.customer.rewards.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.rewards.bean.CustomerBean;
import com.customer.rewards.entity.Customer;
import com.customer.rewards.entity.RewardTransactions;
import com.customer.rewards.repository.CustomerRewardRepository;
import com.customer.rewards.service.CustomerRewardService;
import com.customer.rewards.util.RewardsUtil;

@Service
public class CustomerRewardServiceImpl implements CustomerRewardService {
	Logger logger = LoggerFactory.getLogger(CustomerRewardServiceImpl.class);
	
	@Autowired
	CustomerRewardRepository customerRewardRepository;

	@Autowired
	RewardsUtil rewardsUtil;

	
	public List<Customer> customerRewardsForAll() {
		logger.info("in CustomerRewardServiceImpl->customerRewardsForAll Starts:");

		List<Customer> customerList = (List<Customer>) customerRewardRepository.findAll();
		if (customerList != null) {
			for (Customer customer : customerList) {
				logger.debug("Starts: rewards calculation for customer:"
						+ customer.getName());
				Set<RewardTransactions> setOfTransaction = customer.getTransactions();
				setCustomerRewardsPerMonth(setOfTransaction, customer);
				logger.debug("End : reward calculation for customer" + customer.getName());
			}

		}

		logger.info("in CustomerRewardServiceImpl->customerRewardsForAll Ends:");
		return customerList;
	}

	public Customer customerRewardsById(int customerId) {
		logger.info("in CustomerRewardServiceImpl->customerRewardsById Starts:");

		
		Customer customerReward = customerRewardRepository.findById(customerId).orElse(null);
		if(customerReward != null) {
			logger.debug("Reward calculation for customer Starts:"
					+ customerReward.getName());
			Set<RewardTransactions> setOfTransaction = customerReward.getTransactions();
			setCustomerRewardsPerMonth(setOfTransaction, customerReward);
			logger.debug("Reward calculation for customer End:" + customerReward.getName());
		}
		
		logger.info("in CustomerRewardServiceImpl->customerRewardsById Starts:");

		return customerReward;
	}
	
	private void setCustomerRewardsPerMonth(Set<RewardTransactions> transactions, Customer customer) {
		
		logger.info("in CustomerRewardServiceImpl->setCustomerRewardsPerMonth Starts:");

		
		LocalDate todayDate = LocalDate.now();
		
		for (RewardTransactions transaction : transactions) {
			
			int transactionMon = transaction.getTransactionDate().getMonthValue();
			int transactionYear = transaction.getTransactionDate().getYear();
			
			logger.debug("Start: Rewards for Customer:" + customer.getName() + " for Transaction Id: "
					+ transaction.getId());
			

			if ((todayDate.getYear() == transactionYear) && (todayDate.getMonth().getValue() == transactionMon))
				customer.setThirdMonthRewards(customer.getThirdMonthRewards()
						+ rewardsUtil.calculateRewardAmountPerTrans(transaction.getTransactionAmount()));
			
			else if ((todayDate.minusMonths(1).getYear() == transactionYear)
					&& (todayDate.minusMonths(1).getMonth().getValue() == transactionMon))
				customer.setSecondMonthRewards(customer.getSecondMonthRewards()
						+ rewardsUtil.calculateRewardAmountPerTrans(transaction.getTransactionAmount()));
			else if ((todayDate.minusMonths(2).getYear() == transactionYear)
					&& (todayDate.minusMonths(2).getMonth().getValue() == transactionMon))
				customer.setFirstMonthRewards(customer.getFirstMonthRewards()
						+ rewardsUtil.calculateRewardAmountPerTrans(transaction.getTransactionAmount()));

			logger.debug("in CustomerRewardServiceImpl->setCustomerRewardsPerMonth Ends:  customer:" + customer.getName() + " and Transaction Id:"
					+ transaction.getId());

		}
	}


}

package com.customer.rewards.service;

import java.util.List;

import com.customer.rewards.bean.CustomerBean;
import com.customer.rewards.bean.RewardTransactionBean;
import com.customer.rewards.entity.Customer;
import com.customer.rewards.entity.RewardTransactions;

public interface TransactionService {
	
	int insertTransactionData(RewardTransactionBean bean);
	
}

package com.customer.rewards.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.customer.rewards.entity.RewardTransactions;

@Repository
public interface TransactionRepository extends JpaRepository<RewardTransactions, Long>{

	 @Query(value = "SELECT transaction_seq.nextval FROM dual", nativeQuery = true)
	    public int getNextValTransactionSequence();
}

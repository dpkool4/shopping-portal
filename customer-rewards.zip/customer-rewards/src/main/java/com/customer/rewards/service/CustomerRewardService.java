package com.customer.rewards.service;

import java.util.List;

import com.customer.rewards.bean.CustomerBean;
import com.customer.rewards.entity.Customer;

public interface CustomerRewardService {
	
	List<Customer> customerRewardsForAll();

	Customer customerRewardsById(int customerId);
	
}
